Corrected v8:200 combat/item/effect frames + separate24 movement frames=224 total.
Nitro-Fuel now matches user gold square can reference, including all48 retrieval/drink/cheer poses,4 item frames and UI icon.
Shooter8/projectile4 were resegmented from complete source subjects. Previous cell crops included previous-row dummy feet; selecting the largest fragment alone could choose the dummy base over a smaller projectile.
Main metadata:corrected-v8-atlas.json. Old wrong cup sprites and old sliced shooter/projectile atlases are excluded from this current pack.
Timing4.6s; heal2 hearts capped at max; loot5%; controls and hitboxes unchanged.
Images edited with built-in Image Generation; crop/align/nearest-neighbor scale. Unofficial HoYoverse fan prototype.
