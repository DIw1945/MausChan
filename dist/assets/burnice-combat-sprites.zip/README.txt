Image Generation combat sprite pack
40 frames,96x96 RGBA. Feet anchor:48,75.
Slash: rows DOWN,LEFT,RIGHT,UP;4 columns per row.
Charge: row0 build, row1 ready; columns DOWN,LEFT,RIGHT,UP.
Spin: row2 then row3,8 frames. Dummy: row0 idle,row1 hit;4 frames each.
Base walk sprites are available in the separate movement pack.
Burnice belongs to HoYoverse. Unofficial fan-made prototype.
