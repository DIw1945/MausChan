Defeat v5 complete combat/health pack:128 frames, plus separate movement pack24.
New44 frames:16 dizzy spin,16 collapse,8 dazed lying,4 star twinkles.
Body frames160x160, ground origin80,112. Stars16x16, centre8,8.
Spin2s (16 unique frames, twice), fall1s, lying1.2s before Game Over.
Three stars are drawn individually on an ellipse above the head; no fixed sprite star count.
Full metadata in defeat-v5-atlas.json. Existing v4 art retained.
Built-in Image Generation with transparent gutters, crop/align/nearest-neighbor scale.
Burnice belongs to HoYoverse; unofficial fan-made prototype.
