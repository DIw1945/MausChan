Spiders/Webbed v14:100 selected RGBA frames.
Retains64 directional spiders +4 silk shots +12 Webbed I; replaces12 Webbed II +8 quiet rest.
Stronger torso/shoulder/knee contractions, thicker silk. Struggle8fps/rest4fps.
Burnice160 origin80,112,head40. Last struggle equals first rest.
Built-in Image Generation; original sheets, frame PNGs and prompts retained.
