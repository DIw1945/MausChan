Combat v3 complete pack:56 frames.
Slash and charge-walk:160x160 RGBA, anchor80,112. Rows:down,left,right,up;4 columns.
Stationary charge/spin/dummy:96x96 RGBA, anchor48,75. Per-frame dimensions in JSON.
Left/right slash and all charge walking generated anew. Up/down slash retained from v2.
Whole-subject segmentation keeps complete sword/effects across nominal source cell edges.
Movement idle/walk are in the separate movement pack.
Burnice belongs to HoYoverse; unofficial fan project.
