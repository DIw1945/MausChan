Nitro v7:200 combat/item/effect frames + separate24 movement frames=224 total.
New56:16 fetch from behind,16 drink,16 cheer/raise,4 item,4 sparkle.
4.6 seconds:fetch1.2,sip2,cheer1.4. Heal4 half-heart units only after completion, capped at max.
Body160px,feet80,112; head width40px/body height54px match idle.
Nitro item32px,origin16,26; sparkle24px,centre12,12.
The yard sample gives1 item. Defeated targets roll5% rare drops. PressE or use the item button.
Primary metadata:nitro-v7-atlas.json. Art made with built-in Image Generation.
Unofficial Burnice / HoYoverse fan prototype.
