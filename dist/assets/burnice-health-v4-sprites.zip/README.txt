Complete combat/health v4:84 frames, plus separate movement pack24 frames.
Charge-walk and hurt:160x160, feet anchor80,112. Row order down,left,right,up;4 frames per row.
Shooter:96x96,anchor48,75; row0 idle,row1 firing.
Projectile:24x24,core anchor12,18;4 columns.
Charge-walk resized to match original idle height AND head width, foot origin preserved.
Prior slash/charge/spin/target dummy retained. Per-frame dimensions and origins in JSON.
New hurt/shooter/projectile art uses Image Generation.
Character belongs to HoYoverse; unofficial fan-made study.
