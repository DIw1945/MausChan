Trees v15: four STILL variants, not animation frames.
Built-in Image Generation, transparent alpha preserved.
96x112 frame canvas, anchor48,96, root baseline100.
World positions and18x16 trunk colliders unchanged.
Full original, frames, atlas, metadata, prompt and preparation script retained.
Preparation script uses component_bounds from project tools/repair_nitro_sparkles.py.
