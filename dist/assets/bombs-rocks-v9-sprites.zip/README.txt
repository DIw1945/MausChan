Bombs v9: 20 transparent frames from built-in Image Generation.
4 bomb states (frame 0 unlit, frames 1-3 lit fuse), 8 blast frames, 8 brittle-rock break frames (frame 0 intact).
Bomb canvas64/origin32,50; blast192/96,96; rock96/48,76. Nearest-neighbour scale; original, individual frames and metadata retained.
This pack supplements corrected-v8-atlas.json and burnice-atlas.json.
Q places one bomb; fuse2.2s; radius88; damage180; player damage1 heart.
