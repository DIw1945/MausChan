Spiders/Webbed v13:100 selected RGBA frames.
32 frames per spider: down,left,right,up x (4 walk +4 attack).
4 retained silk shots,12 retained Webbed I,12 new Webbed II,8 breathing rest.
Spider96 origin48,64;shot32 centre16,16;Burnice160 origin80,112/head40.
Webbed II8fps, breathing4fps. Last struggle matches first rest exactly.
Built-in Image Generation; complete-component centre slicing; nearest-neighbour alignment.
