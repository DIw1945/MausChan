Slimes v10: 40 generated RGBA frames.
8 normal green,8 large blue,8 swift pink,4 goo pop,12 Burnice sticky struggle.
Monster/effect canvas96 origin48,76. Burnice canvas160 origin80,112; fixed feet, calibrated body54/head40.
Metadata supplements corrected-v8-atlas.json, burnice-atlas.json and bombs-v9-atlas.json.
Built-in Image Generation; retained originals and prompts; component-centre slicing and nearest-neighbour scale.
