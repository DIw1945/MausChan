Slimes v11: 40 generated RGBA frames; monsters/pop retain v10 art.
12 new restrained Burnice sticky poses, disgusted face, 9fps.
Monster canvas96 origin48,76; Burnice160 origin80,112, calibrated body54/head40.
Built-in Image Generation, complete-component slicing, nearest-neighbour alignment.
