Spiders/Webbed v12:32 Image Generation frames.
8 purple weaver,8 orange hunter,4 silk projectiles,12 lying Webbed poses at8fps.
Spider96 origin48,64;shot32 centre16,16;Burnice160 origin80,112,head40.
Complete-component slicing, body-colour anchors, nearest-neighbour scaling.
Supplements existing movement/v8/v9/v11 atlases; all originals and prompts retained.
