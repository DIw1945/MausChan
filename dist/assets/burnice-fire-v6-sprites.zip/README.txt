Fire v6:144 combat/health/defeat/effect frames + separate24 movement frames=168 total.
Rest8: first frame is the exact final collapse, followed by7 corrected generated breathing poses with arm outward.
Wave8:64px canvas,center32,32; ring8:128px,center64,64.
Full hearts only: slash fires one forward fire crescent; fully charged spin releases8 radial crescents and a fire ring.
20 slash /60 charged damage; each target takes at most one hit per attack, including melee.
Sources created/edited by built-in Image Generation, cropped and nearest-neighbor scaled.
Primary metadata:combat-v6-atlas.json; older metadata is retained for history.
Unofficial fan-made Burnice / HoYoverse prototype.
