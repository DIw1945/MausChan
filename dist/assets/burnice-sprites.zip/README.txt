Burnice White fan-made sprite study
24 frames, 64x64 RGBA. Row order: down, left, right, up.
Columns 0-1: idle (2 fps). Columns 2-5: walk (8 fps).
Origin: bottom-centre (32,61). Movement uses 8 directions; art uses 4 facing directions.
Sprites generated using Image Generation from a character reference, then cropped and reduced with nearest-neighbor.
Character belongs to HoYoverse; this pack does not grant rights to the original character.
